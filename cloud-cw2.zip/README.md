# Coursework template

This is the template that you can use for your coursework 1 part 2.

It is a simple chat application written in Javascript, using the Express server framework, VueJS and Socket.IO.

## Running

### Locally

Start the application using:
```
$ npm start
```

### Deploying to the cloud
